---
name: Bug report
about: 错误反馈/Bug report / 不使用此模板提交会被close / Will close without this template
title: "[BUG] "
labels: bug
assignees: ''

---

**什么情况/What happened?**

如无法开机/模块无效等

**Xposed模块列表/Xposed Module List**

允许截图/Screenshot allowed

**Magisk模块列表/Magisk Module List**

允许截图/Screenshot allowed

**EdXposed及Riru版本/Versions of EdXposed and Riru**

EdXposed:

Riru:

**相关Logcat/Logcat**

有助于定位问题，必须使用我们的log抓取模块抓取/It can help us to locate issue, must use our logcat module
