package com.elderdrivers.riru.edxp.entry;

public class HookImpl<T> implements Hook {

}
