package com.elderdrivers.riru.edxp.entry;

public interface Hook {
}
