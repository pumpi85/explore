package com.elderdrivers.riru.edxp.art;

import java.lang.reflect.Member;

public class Heap {

    public static native int waitForGcToComplete(long thread);

}
