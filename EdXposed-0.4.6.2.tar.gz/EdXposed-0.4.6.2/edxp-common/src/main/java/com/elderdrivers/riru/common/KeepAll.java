package com.elderdrivers.riru.common;

public interface KeepAll {
}
